<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('Barang_model');
		$this->load->helper('url');
    }

	public function listBarang() {
		$data['barang'] = $this->Barang_model->get_all_barang();
		$this->load->view('list_barang', $data);
	}
    
    public function index() {
        // $data['barang'] = $this->Barang_model->home_view();
        $this->load->view('home');
    }


   
    public function view($id) {
        $data['barang'] = $this->Barang_model->get_barang_by_id($id);
        $this->load->view('viewby_id', $data);
    }

    
    public function create() {
        if ($this->input->post()) {
            $data = array(
                'Kode_Barang' => $this->input->post('Kode_Barang'),
                'Nama_Barang' => $this->input->post('Nama_Barang'),
                'Kategori_Barang' => $this->input->post('Kategori_Barang'),
                'Deskripsi_Barang' => $this->input->post('Deskripsi_Barang'),
                'Harga_Beli' => $this->input->post('Harga_Beli'),
                'Harga_Jual' => $this->input->post('Harga_Jual'),
                'Stok_Barang' => $this->input->post('Stok_Barang'),
                'Supplier_Barang' => $this->input->post('Supplier_Barang'),
                'Tanggal_Masuk' => $this->input->post('Tanggal_Masuk')
            );
            $this->Barang_model->insert_barang($data);
            redirect('barang');
        } else {
            $this->load->view('add_barang');
        }
    }

    
    public function edit($id) {
        if ($this->input->post()) {
            $data = array(
                'Kode_Barang' => $this->input->post('Kode_Barang'),
                'Nama_Barang' => $this->input->post('Nama_Barang'),
                'Kategori_Barang' => $this->input->post('Kategori_Barang'),
                'Deskripsi_Barang' => $this->input->post('Deskripsi_Barang'),
                'Harga_Beli' => $this->input->post('Harga_Beli'),
                'Harga_Jual' => $this->input->post('Harga_Jual'),
                'Stok_Barang' => $this->input->post('Stok_Barang'),
                'Supplier_Barang' => $this->input->post('Supplier_Barang'),
                'Tanggal_Masuk' => $this->input->post('Tanggal_Masuk')
            );
            $this->Barang_model->update_barang($id, $data);
            redirect('barang');
        } else {
            $data['barang'] = $this->Barang_model->get_barang_by_id($id);
            $this->load->view('edit_barang', $data);
        }
    }

 
    public function delete($id) {
        $this->Barang_model->delete_barang($id);
        redirect('barang');
    }
	public function search() {
        $keyword = $this->input->post('keyword');
        $data['barang'] = $this->Barang_model->search_barang($keyword);
        $this->load->view('list_barang', $data);
    }


	
}
