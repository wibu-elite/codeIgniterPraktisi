<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Barang_model extends CI_Model {

    public function __construct() {
        parent::__construct();
        $this->load->database();
    }


    public function get_all_barang() {
        $query = $this->db->get('barang'); 
        return $query->result_array();
    }

   
    public function get_barang_by_id($id) {
        $query = $this->db->get_where('barang', array('ID' => $id));
        return $query->row_array();
    }


    public function insert_barang($data) {
        return $this->db->insert('barang', $data);
    }

   
    public function update_barang($id, $data) {
        $this->db->where('ID', $id);
        return $this->db->update('barang', $data);
    }

      public function delete_barang($id) {
        $this->db->where('ID', $id);
        return $this->db->delete('barang');
    }
	public function search_barang($keyword) {
        $this->db->like('Kode_Barang', $keyword);
        $this->db->or_like('Nama_Barang', $keyword);
        $this->db->or_like('Kategori_Barang', $keyword);
        $this->db->or_like('Deskripsi_Barang', $keyword);
        $query = $this->db->get('barang');
        return $query->result_array();
    }
}
