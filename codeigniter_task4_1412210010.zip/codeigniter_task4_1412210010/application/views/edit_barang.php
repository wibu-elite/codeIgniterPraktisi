<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Barang</title>
</head>
<body>
	<style>
	
		form {
		  width: 600px; 
		  margin: 40px auto; 
		  padding: 30px;
		  border: 1px solid #ddd;
		  border-radius: 8px; 
		  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
		  background-color: #fff; 
		}

	
		h1 {
		  font-size: 2.5em;
		  font-weight: bold;
		  color: #333; 
		  margin-bottom: 20px;
		  text-align: center;
		}

		
		label {
		  display: block;
		  margin-bottom: 5px;
		  font-weight: bold;
		  color: #666; 
		}

		
		input[type="text"],
		input[type="number"],
		input[type="date"],
		textarea {
		  width: 100%;
		  padding: 12px;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		  margin-bottom: 15px;
		  font-size: 16px;
		}

		
		input[type="text"],
		input[type="number"],
		input[type="date"],
		textarea:focus {
		  outline: none;
		  border-color: #4CAF50; 
		}

		
		input[type="submit"] {
		  background-color: #4CAF50; 
		  color: white;
		  padding: 14px 20px;
		  border: none;
		  border-radius: 4px;
		  cursor: pointer;
		  transition: background-color 0.3s ease; 
		}

		input[type="submit"]:hover {
		  background-color: #45a049; 
		}

		/* .error {
		  color: red;
		  font-size: 14px;
		  margin-bottom: 10px;
		} */

	</style>
    <h1>Edit Barang</h1>
    <form action="<?php echo site_url('barang/edit/'.$barang['ID']); ?>" method="post">
        <label for="Kode_Barang">Kode Barang:</label><br>
        <input type="text" id="Kode_Barang" name="Kode_Barang" value="<?php echo $barang['Kode_Barang']; ?>"><br>
        
        <label for="Nama_Barang">Nama Barang:</label><br>
        <input type="text" id="Nama_Barang" name="Nama_Barang" value="<?php echo $barang['Nama_Barang']; ?>"><br>
        
        <label for="Kategori_Barang">Kategori Barang:</label><br>
        <input type="text" id="Kategori_Barang" name="Kategori_Barang" value="<?php echo $barang['Kategori_Barang']; ?>"><br>
        
        <label for="Deskripsi_Barang">Deskripsi Barang:</label><br>
        <textarea id="Deskripsi_Barang" name="Deskripsi_Barang"><?php echo $barang['Deskripsi_Barang']; ?></textarea><br>
        
        <label for="Harga_Beli">Harga Beli:</label><br>
        <input type="number" id="Harga_Beli" name="Harga_Beli" value="<?php echo $barang['Harga_Beli']; ?>"><br>
        
        <label for="Harga_Jual">Harga Jual:</label><br>
        <input type="number" id="Harga_Jual" name="Harga_Jual" value="<?php echo $barang['Harga_Jual']; ?>"><br>
        
        <label for="Stok_Barang">Stok Barang:</label><br>
        <input type="number" id="Stok_Barang" name="Stok_Barang" value="<?php echo $barang['Stok_Barang']; ?>"><br>
        
        <label for="Supplier_Barang">Supplier Barang:</label><br>
        <input type="text" id="Supplier_Barang" name="Supplier_Barang" value="<?php echo $barang['Supplier_Barang']; ?>"><br>
        
        <label for="Tanggal_Masuk">Tanggal Masuk:</label><br>
        <input type="date" id="Tanggal_Masuk" name="Tanggal_Masuk" value="<?php echo $barang['Tanggal_Masuk']; ?>"><br><br>
        
        <input type="submit" value="Update">
    </form>
</body>
</html>
