<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Detail Barang</title>
</head>
<body>
	<style>
		
		table {
		  border-collapse: collapse;
		  width: 80%;
		  margin: 40px auto; 
		  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
		  background-color: #fff; 
		}

		th, td {
		  padding: 15px;
		  border: 1px solid #ddd;
		  text-align: left;
		}

		th {
		  background-color: #f5f5f5; 
		  color: #333; 
		  font-weight: bold;
		}

		
		tr:nth-child(odd) {
		  background-color: #f9f9f9; 
		}

		h1 {
			text-align: center;
		}

		
		.id {
		  width: 50px; 
		  text-align: center;
		}

		.kode-barang {
		  width: 150px; 
		}

		.nama-barang {
		  width: 300px; 
		}

		.kategori-barang {
		  width: 150px; 
		}

		.deskripsi-barang {
		  width: 400px; 
		}

		.harga-beli,
		.harga-jual {
		  width: 100px; 
		  text-align: right; 
		}

		.stok-barang {
		  width: 80px; 
		  text-align: center;
		}

		.supplier-barang {
		  width: 200px; 
		}

		.tanggal-masuk {
		  width: 120px; 
		}

		
		/* tfoot th {
		  background-color: #e0e0e0; 
		} */

		
		a {
		  color: #4CAF50; 
		  text-decoration: none; 
		  padding: 10px 20px; 
		  border: 1px solid #4CAF50; 
		  border-radius: 5px; 
		  transition: background-color 0.3s ease; 
		  display: block; 
		  margin: 20px auto;
		  text-align: center; 
		}

		a:hover {
		  background-color: #45a049; 
		}

	</style>
    <h1>Detail Barang</h1>
    <table border="1">
        <tr>
            <th>ID</th>
            <td><?php echo $barang['ID']; ?></td>
        </tr>
        <tr>
            <th>Kode Barang</th>
            <td><?php echo $barang['Kode_Barang']; ?></td>
        </tr>
        <tr>
            <th>Nama Barang</th>
            <td><?php echo $barang['Nama_Barang']; ?></td>
        </tr>
        <tr>
            <th>Kategori Barang</th>
            <td><?php echo $barang['Kategori_Barang']; ?></td>
        </tr>
        <tr>
            <th>Deskripsi Barang</th>
            <td><?php echo $barang['Deskripsi_Barang']; ?></td>
        </tr>
        <tr>
            <th>Harga Beli</th>
            <td><?php echo $barang['Harga_Beli']; ?></td>
        </tr>
        <tr>
            <th>Harga Jual</th>
            <td><?php echo $barang['Harga_Jual']; ?></td>
        </tr>
        <tr>
            <th>Stok Barang</th>
            <td><?php echo $barang['Stok_Barang']; ?></td>
        </tr>
        <tr>
            <th>Supplier Barang</th>
            <td><?php echo $barang['Supplier_Barang']; ?></td>
        </tr>
        <tr>
            <th>Tanggal Masuk</th>
            <td><?php echo $barang['Tanggal_Masuk']; ?></td>
        </tr>
    </table>
    <br>
    <a href="<?php echo site_url('barang'); ?>">Kembali ke Daftar Barang</a>
</body>
</html>
