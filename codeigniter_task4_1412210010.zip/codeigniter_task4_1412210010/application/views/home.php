<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - Landing Page</title>
    <link rel="stylesheet" href="<?= base_url('node_modules/bootswatch/dist/quartz/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo base_url('node_modules/js/bootstrap.min.js')?>"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding-top: 56px; /* Height of the fixed navbar */
        }
        .navbar-custom {
            background-color: rgba(52, 58, 64, 0.8); /* Dark background with transparency */
        }
        .navbar-dark .navbar-nav .nav-link, .navbar-dark .navbar-brand {
            color: #ffffff;
            text-shadow: 0px 0px 3px rgba(0, 0, 0, 0.6);
        }
        .hero {
            background: #343a40;
            color: white;
            padding: 50px 0;
            text-align: center;
        }
        .hero h1 {
            font-size: 3em;
            margin-bottom: 20px;
        }
        .hero p {
            font-size: 1.2em;
            margin-bottom: 40px;
        }
        .footer {
            background: #343a40;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        .footer a {
            color: #f8f9fa;
            margin: 0 10px;
            text-decoration: none;
        }
        .footer a:hover {
            color: #adb5bd;
        }
        .section {
            padding: 50px 0;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark navbar-custom fixed-top">
        <div class="container-fluid">
            <a class="navbar-brand" href="#">MyStore</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('/'); ?>">Home<span class="visually-hidden"></span></a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="<?php echo site_url('barang/listBarang'); ?>">Data Barang</a></li>
                    <li class="nav-item"><a class="nav-link" href="#me">About</a></li>
                </ul>

                <!-- Form Search -->
                <form class="d-flex" action="<?php echo site_url('barang/search'); ?>" method="post" class="mb-3">
                    <input class="form-control me-sm-2" type="search" name="keyword" placeholder="Search">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>

    <div class="hero">
        <div class="container">
            <h1>Welcome to MyPage</h1>
            <p>Let Me Change The World</p>
            <a href="<?php echo site_url('barang'); ?>" class="btn btn-primary">View Our Products</a>
        </div>
    </div>

    <div class="container section my-5">
        <div class="row">
            <div class="col-lg-4">
                <h3>Product Card 1</h3>
                <p>Coming Soon.</p>
            </div>
            <div class="col-lg-4">
                <h3>Product Card 1</h3>
                <p>Coming Soon.</p>
            </div>
            <div class="col-lg-4">
                <h3>Product Card 1</h3>
                <p>Coming Soon.</p>
            </div>
        </div>
    </div>

    <!-- Additional sections to ensure scrolling -->
    <div class="container section">
        <h2>More About Us</h2>
        <p>I am Miftahurrohman, a Student of Informatics Engineering at PGRI Ronggolawe University, Tuban. I love coding, and am learning web development Javascript and PHP Programming Languages.</p>
    </div>
    <div class="container section">
        <h2>My Ability</h2>
        <p>Use MS Office | Public Speaking | Problem Solving</p>
    </div>
    <div class="container section">
        <h2>Contact Me</h2>
        <p>NPM 1412210010 | 0823-4082-3214 | miftahurrohman100@gmail.com</p>
    </div>

    <div class="footer" id="me">
        <div class="container">
            <p>&copy; 2024 MyPage. All rights reserved.</p>
            <p>
                <a href="#">Privacy Policy</a> |
                <a href="#">Terms of Service</a> |
                <a href="#">Contact Me</a>
            </p>
        </div>
    </div>

    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
