<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>List Barang</title>
    <link rel="stylesheet" href="<?= base_url('node_modules/bootswatch/dist/quartz/bootstrap.min.css') ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="<?php echo base_url('node_modules/js/bootstrap.min.js')?>"></script>
    <style>
        /* table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px auto;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            padding: 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #f5f5f5;
            color: #333;
            font-weight: bold;
        }
        .id { width: 50px; text-align: center; }
        .kode-barang { width: 150px; }
        .nama-barang { width: 250px; }
        .kategori-barang { width: 150px; }
        .deskripsi-barang { width: 300px; }
        .harga-beli, .harga-jual { width: 100px; text-align: right; }
        .stok-barang { width: 80px; text-align: center; }
        .supplier-barang { width: 150px; }
        .tanggal-masuk { width: 120px; }
        .aksi { width: 180px; text-align: center; }
        thead th { background-color: #e0e0e0; }
        .empty-message {
            text-align: center;
            font-style: italic;
            color: #888;
        }
        a {
            text-decoration: none;
            transition: background-color 0.3s ease;
        } */
        .btn-danger {
            color: lightcoral;
        }
        .btn-info {
            color: lightblue;
        }
        .btn-warning {
            color: black;
        }
        .btn-danger:hover {
            color: darkred;
        }
        .btn-info:hover {
            color: darkblue;
        }
        .table-container {
            /* display: flex;
            flex-direction: column; */
			position: relative;
        }
        .table-container .btn-primary {
			position: absolute;
            bottom: -97px;
            right: 0;	
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg bg-dark" data-bs-theme="dark">
        <div class="container-fluid">
            <!-- <a class="navbar-brand" href="#">Navbar</a> -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor02" aria-controls="navbarColor02" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarColor02">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="<?php echo site_url('/'); ?>">Home<span class="visually-hidden">(current)</span></a>
                    </li>
                    <li class="nav-item"><a class="nav-link" href="#">Data Barang</a></li>
                    <!-- <li class="nav-item"><a class="nav-link" href="#">Pricing</a></li> -->
                    <li class="nav-item"><a class="nav-link" href="<?php echo site_url('/#me'); ?>">About</a></li>
                    <li class="nav-item dropdown">
                        <!-- <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Dropdown</a> -->
                        <div class="dropdown-menu">
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <a class="dropdown-item" href="#">Something else here</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Separated link</a>
                        </div>
                    </li>
                </ul>

                <!-- Form Search -->
                <form class="d-flex" action="<?php echo site_url('barang/search'); ?>" method="post" class="mb-3">
                    <input class="form-control me-sm-2" type="search" name="keyword" placeholder="Search">
                    <button class="btn btn-secondary my-2 my-sm-0" type="submit">Search</button>
                </form>
            </div>
        </div>
    </nav>
    <div class="container mt-4">
        <div class="table-container">
            <a href="<?php echo site_url('barang/create'); ?>" class="btn btn-primary mb-3">Tambah Barang</a>
            <table class="table table-hover">
                <thead>
                    <tr class="table-secondary">
                        <th>ID</th>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Kategori Barang</th>
                        <th>Deskripsi Barang</th>
                        <th>Harga Beli</th>
                        <th>Harga Jual</th>
                        <th>Stok Barang</th>
                        <th>Supplier Barang</th>
                        <th>Tanggal Masuk</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($barang)): ?>
                        <tr>
                            <td colspan="11" class="text-center">Tidak ada barang ditemukan</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($barang as $b): ?>
                            <tr>
                                <td><?php echo $b['ID']; ?></td>
                                <td><?php echo $b['Kode_Barang']; ?></td>
                                <td><?php echo $b['Nama_Barang']; ?></td>
                                <td><?php echo $b['Kategori_Barang']; ?></td>
                                <td><?php echo $b['Deskripsi_Barang']; ?></td>
                                <td><?php echo $b['Harga_Beli']; ?></td>
                                <td><?php echo $b['Harga_Jual']; ?></td>
                                <td><?php echo $b['Stok_Barang']; ?></td>
                                <td><?php echo $b['Supplier_Barang']; ?></td>
                                <td><?php echo $b['Tanggal_Masuk']; ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                        <a href="<?php echo site_url('barang/view/'.$b['ID']); ?>" class="btn btn-info btn-sm"><i class="fa fa-eye"></i></a>
                                        <a href="<?php echo site_url('barang/edit/'.$b['ID']); ?>" class="btn btn-warning btn-sm"><i class="fa fa-pencil"></i></a>
                                        <a href="<?php echo site_url('barang/delete/'.$b['ID']); ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')"><i class="fa fa-trash"></i></a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="<?= base_url('assets/js/bootstrap.bundle.min.js') ?>"></script>
</body>
</html>
