-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2024 at 07:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.1.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokoapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `ID` int(10) NOT NULL,
  `Kode_Barang` varchar(20) NOT NULL,
  `Nama_Barang` varchar(100) NOT NULL,
  `Kategori_Barang` varchar(50) NOT NULL,
  `Deskripsi_Barang` text DEFAULT NULL,
  `Harga_Beli` float NOT NULL,
  `Harga_Jual` float NOT NULL,
  `Stok_Barang` int(11) NOT NULL,
  `Supplier_Barang` varchar(100) NOT NULL,
  `Tanggal_Masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`ID`, `Kode_Barang`, `Nama_Barang`, `Kategori_Barang`, `Deskripsi_Barang`, `Harga_Beli`, `Harga_Jual`, `Stok_Barang`, `Supplier_Barang`, `Tanggal_Masuk`) VALUES
(2, 'MKR002', 'Long Potato', 'Makanan Ringan', 'Bahan baku utama Kentang dengan tambahan Keju', 8000, 10000, 100, 'PT. Kuliner Enak', '2024-03-16'),
(3, 'MKB001', 'Nasi Puyung', 'Makanan Berat', 'Salah satu makanan khas Lombok Tengah yaitu dari Puyung', 16000, 18000, 50, 'PT. Puyung Hay', '2024-05-08'),
(4, 'MM001', 'Es Semangka Vrindafan', 'Minuman khas dari vrindafan', 'Minuman', 5000, 8000, 100, 'PT. Vrindafan', '2024-05-17'),
(5, 'MM002', 'Durmed', 'Jus durian', 'Minuman', 8000, 10000, 90, 'PT. Es Kimo', '2024-04-10'),
(6, 'MM003', 'Dawet Ayu', 'Es Dawet dengan santan kelapa', 'Minuman', 8000, 10000, 70, 'PT. Es Kimo', '2024-04-10'),
(7, 'MKB002', 'Ayam Geprek', 'Makanan Berat', '', 15000, 21000, 100, 'PT. Geprek Chicken', '2024-04-01'),
(8, 'MKR003', 'Teri Crispy', 'Makanan Ringan', '', 7000, 11000, 60, 'PT. Kuliner Enak', '2024-04-30'),
(9, 'MKR004', 'Onion Ring', 'Makanan Ringan', 'Bawang Bombay Crispy', 8000, 12000, 40, 'PT. Kuliner Enak', '2024-04-30'),
(12, 'MKR005', 'Daun Pisang Crispy', 'Makanan Ringan', 'Olahan daun pisang muda yang dibumbui dengan tepung crispy', 10000, 15000, 25, 'PT. Kuliner Enak', '2024-04-30'),
(13, 'MKR006', 'Piscok', 'Makanan Ringan', 'Pisang Coklat Keju, Pisang Goreng ditaburi keju dan coklat', 6000, 10000, 50, 'Aneka Snack', '2024-05-08');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
